// SimCare Service Worker v1.0
const CACHE_NAME = 'simcare-v1';
const FILES = [
  './SimCare.html',
  './SimO2-IFSI.html',
  './SimPerf-IFSI.html',
  './SimGluco-IFSI.html',
  './SimContention-IFSI.html',
  './SimCare-icon.svg',
  './manifest.json',
];

// Installation — mise en cache de tous les fichiers
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(FILES))
      .then(() => self.skipWaiting())
  );
});

// Activation — nettoyage des anciens caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — cache d'abord, réseau ensuite
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(cached => cached || fetch(event.request))
      .catch(() => caches.match('./SimCare.html'))
  );
});
